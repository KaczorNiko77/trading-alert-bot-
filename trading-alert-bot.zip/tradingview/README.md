# TradingView version

`confluence-strategy.pine` is the same confluence logic from the Node bot
(`src/composite.mjs`, `src/strategy.mjs`, `src/levels.mjs`), ported to Pine
Script so you can view it on a live TradingView chart and use TradingView's
own Strategy Tester and alert system.

**Not tested end-to-end** — I don't have access to run Pine Script, so I
wrote this from well-established Pine v6 syntax but haven't compiled it
myself. Paste it in, and if the Pine Editor flags a compile error, send it
back and I'll fix it.

**Missing vs. the Node bot:** news sentiment. Pine Script can't make
outbound HTTP requests to arbitrary APIs, so there's no way to call Claude
or pull RSS feeds from inside a chart script. The composite score here is
technicals + volume, with an optional ADX trend-strength filter
(`adxMinTrend` input) and an optional 200-period SMA long-term trend
filter (`longTrendLen` input) — **both off (0) by default**. They're real,
published techniques (see the main README's "Honest expectations"
section), but a large backtest on ~2500 daily BTC/ETH/SOL candles showed
them making returns measurably *worse* over that window, not better — it
was a trend-heavy period, not the choppy conditions these filters are
meant to help with. Try enabling them on your own symbol/timeframe in
Strategy Tester rather than assuming they'll help.

Entry/exit matches `backtestConfluenceStrategy()` in `src/backtest.mjs`:
long-only, exits via a 1.5x/3x-ATR stop/target **fixed at the ATR value
when the trade opened** (not recalculated as price moves) or a reversal
signal, whichever comes first. Strategy Tester numbers should be in the
same ballpark as `npm run backtest` (small differences expected —
TradingView's data feed/candle timing won't be pixel-identical to
Binance's, and `npm run backtest` defaults to fetching up to 3000
candles vs. however much history your chart has loaded).

The script also charges a 0.05%-per-order commission by default (~0.1%
round trip) so the Strategy Tester doesn't show an unrealistically clean
number — real trading has costs. Adjust the commission input to match your
actual broker.

**Position sizing** (`riskPct` input, default 1%): each trade is sized so
that hitting its stop loses exactly that % of equity, instead of betting
100% of equity every time regardless of stop distance. This matters a
lot — on a BTCUSDT daily backtest, full-equity sizing got +365% return
with a **-37.6% max drawdown**; 1%-risk sizing got +41.2% return with
only **-7.0% drawdown**. Less return, dramatically less risk — set
`riskPct` to 0 to go back to 100%-of-equity sizing if you want to compare.

## Add it to a chart

1. Open TradingView, open a chart for the symbol you want (e.g. BTCUSD,
   XAUUSD), open the **Pine Editor** tab at the bottom.
2. New blank script → paste in the contents of `confluence-strategy.pine`
   → **Save** → **Add to chart**.
3. You'll see buy/sell labels on the chart, plus a **Strategy Tester** tab
   with win rate, return, drawdown, equity curve — TradingView's native
   version of what `npm run backtest` prints to the terminal.

## Wire alerts to Telegram (no relay server needed)

TradingView can POST an alert straight to Telegram's API if the alert
message is valid JSON matching what Telegram expects — the script already
builds that JSON for you.

1. In the script's inputs, set **Telegram chat_id** to your chat ID (the
   same one from the Node bot's `.env` — see the main README if you need
   to look it up again).
2. On the chart, click **Alert** (clock icon) → Condition: pick this
   script → Condition: **"Any alert() function call"** → Trigger: **Once
   Per Bar Close** (so it fires on confirmed candles, not mid-candle
   noise).
3. Under **Notifications**, enable **Webhook URL** and set it to:
   `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/sendMessage`
   (same bot token as the Node bot — you can run both against the same
   Telegram bot with no conflict).
4. Create the alert. The composite bullish/bearish signal will now post
   directly to your Telegram chat whenever it fires on this chart.

For the crossing signals (RSI oversold/overbought, golden/death cross),
repeat step 2 but pick the specific `alertcondition()` in the dropdown
instead of "Any alert() function call" — those use static message
templates (no JSON/webhook trick needed) so they work fine as a normal
TradingView notification (app push, email, etc.) too, not just webhook.

## Caveats specific to this version

- **Webhook alerts require a paid TradingView plan** (Pro tier or above)
  — free accounts can create alerts but not webhook notifications. Check
  current TradingView pricing if you're not sure what plan you're on.
- Real fills and slippage will still differ from Strategy Tester's
  simulation even with risk-based sizing on.
- **Timeframe matters enormously** — this was built and validated on
  daily candles. A live TradingView test on 1-minute gold lost heavily;
  the same strategy on 1h gold (Dec 2024-Sep 2026, 154 trades) returned
  +19.8% with a believable 1.152 profit factor. Don't trust this much
  below 1h without re-validating in Strategy Tester first — the input
  periods (20/50-SMA, 14-RSI, MACD 12/26/9) are tuned for daily-scale
  moves and mostly just trade noise on very short timeframes.
- One chart = one symbol/timeframe. To watch BTC, ETH, SOL, and gold
  simultaneously like the Node bot does, you need the script added to
  four separate charts (or four separate alerts on a multi-chart
  layout), each with its own alert configured.
