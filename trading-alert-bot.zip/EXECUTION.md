# MT5 execution bridge (demo only)

`npm run execute` connects to an MT5 account via [MetaApi](https://metaapi.cloud)
and can place real orders — currently wired up for gold only, using its
validated 1h + ADX/SMA200-filter config (see main README "Honest
expectations"). **This has not been tested against a real MetaApi/MT5
account** — there's no account in the environment this was built in to test
against. You're the first real test. Expect to hit an error on your first
run and report it back so it can get fixed, the same way the Pine script and
Telegram bot both needed a couple of fix-and-retry rounds before they worked.

**Use a demo account. Not live. Not yet.** See the "Going live" section at
the bottom for what that would actually require, and why this doc doesn't
walk you through it yet.

## What's actually built

- **Dry run by default.** `EXECUTION_ENABLED` must be the literal string
  `"true"` for any real order to place. Anything else — unset, `"false"`,
  a typo — runs the exact same signal-evaluation pipeline and logs exactly
  what it would have done, without calling any order-placement API.
- **Kill switch.** Set `KILL_SWITCH=true`, or create an empty file named
  `KILL_SWITCH` in the repo root, and every run skips entirely — no deploy
  needed, works even mid-incident.
- **Daily loss limit** (`MAX_DAILY_LOSS_PCT`, default 3%). Tracks equity at
  the start of each UTC day; if current equity has dropped that much from
  the day's starting point, no new positions open for the rest of the day.
  Existing positions aren't abandoned — their stop-loss/take-profit are
  already resting orders on the broker, so they get managed either way.
- **Hard position size cap** (`MAX_POSITION_PCT`, default 10%), independent
  of the risk-based sizing calculation — protects against a sizing bug
  (e.g. a miscalculated stop distance) resulting in a much larger position
  than intended.
- **One position at a time per symbol.** Won't pyramid/stack entries; a
  signal in the direction it's already positioned is a no-op, a signal in
  the opposite direction closes the existing position (same "reversal"
  exit rule the backtest validated).
- Same signal logic as `alert.mjs` — both import `src/signal.mjs`, so they
  can't quietly diverge on what counts as a signal. News sentiment is
  deliberately **not** included in execution decisions, even if you have
  `ANTHROPIC_API_KEY` set for the alert bot — it was never part of what got
  backtested, so execution sticks to exactly the config that was validated.
- **Telegram gets told when a trade actually closes.** Each run checks MT5's
  deal history since the last check (filtered to this bot's own trades by
  magic number, so a shared account's manual trades don't get misreported)
  and posts whether each closed position hit its stop-loss, its take-profit,
  or got closed by a reversal signal, with the P&L.
- **Breakeven suggestions.** Once an open position has moved at least
  halfway to its target, the bot notifies you to consider moving its
  stop-loss to breakeven (entry price + a small buffer to cover spread/
  commission) — standard risk management once a trade's proven itself
  right. Suggestion-only by default; set `AUTO_BREAKEVEN=true` (needs
  `EXECUTION_ENABLED=true` too) to have it actually move the stop instead
  of just telling you. Each position only gets one suggestion/action, not
  a repeat every run.

## A real security tradeoff, disclosed

MetaApi's official Node SDK (`metaapi.cloud-sdk`) pulls in dependencies with
disclosed vulnerabilities — at install time this repo found 2 critical and
4 high-severity issues (an unmaintained crypto library with a broken
password-hashing scheme, old `axios`/`lodash` versions with SSRF and
prototype-pollution issues). `package.json` forces patched versions of the
worst offenders via npm's `overrides` field, which brought it down to 0
critical/high — 8 moderate/low remain with no fix currently available
upstream (an old elliptic-curve library and a ReDoS in the WebSocket layer,
both several dependencies deep in MetaApi's real-time sync code). Run
`npm audit` yourself to see the current state before deciding this is
acceptable for your use — it may look different by the time you read this
if MetaApi or their dependencies update.

## Setup

1. **Get a demo MT5 account.** Any MT5 broker's app/site can create one for
   free — search "[your broker] MT5 demo account" or use a broker you
   already have. You'll get a login number, password, and server name
   (e.g. `ICMarkets-Demo`).
2. **Sign up at [metaapi.cloud](https://metaapi.cloud)** (free tier
   available) and get an API token from their dashboard.
3. **Copy `.env.example` to `.env`** and fill in `METAAPI_TOKEN`,
   `MT5_LOGIN`, `MT5_PASSWORD`, `MT5_SERVER` with your **demo** account's
   details. Leave `EXECUTION_ENABLED` unset for now.
4. **Check `watchlist.json`'s gold entry**: `mt5Symbol` is set to
   `"XAUUSD"` — open your MT5 terminal's Market Watch and confirm that's
   the exact symbol name your broker uses (some use `XAUUSD.m`, `GOLD`, or
   similar). Fix it if it doesn't match.
5. **Run a dry run:**
   ```bash
   export $(cat .env | xargs)
   npm run execute
   ```
   First run may take a minute or two — MetaApi has to provision and
   deploy the account connection. Read the output carefully; it logs
   everything it's evaluating, including "no signal" for symbols with
   nothing happening.
6. **Run it a handful more times** (a few minutes apart, or set up the
   `execute.yml` GitHub Action and trigger it manually from the Actions
   tab a few times) and check the dry-run logs/Telegram messages make
   sense before ever touching `EXECUTION_ENABLED`.
7. **Only once you're confident the dry runs look right**, set
   `EXECUTION_ENABLED=true` in `.env` (or as a repo secret) and re-run.
   Check your MT5 terminal directly — don't just trust the bot's own
   report — to confirm the order actually appears with the size and
   stop/target you expected.

## Automate it (once you trust the dry runs)

`.github/workflows/execute.yml` exists but is **manual-trigger only** on
purpose — no schedule. Trigger it from the repo's Actions tab. Once you've
watched it behave correctly several times, you can add a `schedule:`
trigger yourself (copy the cron syntax from `alert.yml`) — that's a choice
this doc deliberately leaves to you rather than turning on unattended
automation by default.

Required repo secrets: `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`,
`TWELVEDATA_API_KEY`, `METAAPI_TOKEN`, `MT5_LOGIN`, `MT5_PASSWORD`,
`MT5_SERVER`. Optional: `EXECUTION_ENABLED`, `RISK_PCT_PER_TRADE`,
`MAX_POSITION_PCT`, `MAX_DAILY_LOSS_PCT`, `KILL_SWITCH`, `AUTO_BREAKEVEN`.

## Going live

Not covered here yet, deliberately. Before even considering it:

- A real track record on demo — weeks, not a handful of runs — comparing
  actual results against what the backtest predicted (same discipline as
  the TradingView validation: does reality match the expectation, or
  diverge and need investigating).
- Re-read the main README's prop-firm/funded-account warning if this MT5
  account is ever a funded account, not your own capital — the same
  EA/signal-bot restrictions likely apply.
- Confirm the safety limits above (daily loss limit, position cap, kill
  switch) at levels you're actually comfortable with real money behind —
  the defaults here are reasonable starting points, not a recommendation
  for any specific account size or risk tolerance.
- Understand that everything in "A real security tradeoff, disclosed"
  above applies with real money instead of demo money once you flip that
  switch.
