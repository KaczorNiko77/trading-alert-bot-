/**
 * Volume-spike detector: flags when a candle's volume is unusually large
 * relative to its recent history. This is the honest, no-paid-API proxy
 * for "big players moving" — real whale-wallet tracking needs a paid
 * on-chain data service (Nansen, Arkham, Whale Alert, etc.) this bot
 * doesn't have access to. A volume spike just means "a lot more of this
 * asset traded hands than usual" — it doesn't tell you who or why.
 */
export function volumeSpike(volumes, { lookback = 20, multiplier = 2.5 } = {}) {
  if (volumes.length < lookback + 1) return null;
  const recent = volumes.slice(-lookback - 1, -1); // excludes the current candle
  const avg = recent.reduce((a, b) => a + b, 0) / recent.length;
  const current = volumes[volumes.length - 1];
  if (avg === 0) return null;
  const ratio = current / avg;
  return {
    isSpike: ratio >= multiplier,
    ratio,
    currentVolume: current,
    avgVolume: avg,
  };
}

/** Series version of volumeSpike(), O(n) via a rolling sum instead of re-slicing per index. */
export function volumeSpikeSeries(volumes, { lookback = 20, multiplier = 2.5 } = {}) {
  const out = new Array(volumes.length).fill(null);
  let sum = 0;
  for (let i = 0; i < volumes.length; i++) {
    // Rolling sum of the `lookback` candles strictly before i.
    if (i >= 1) sum += volumes[i - 1];
    if (i >= lookback + 1) sum -= volumes[i - lookback - 1];
    if (i >= lookback && sum > 0) {
      const avg = sum / lookback;
      const ratio = volumes[i] / avg;
      out[i] = { isSpike: ratio >= multiplier, ratio, currentVolume: volumes[i], avgVolume: avg };
    }
  }
  return out;
}
