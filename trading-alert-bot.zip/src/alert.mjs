import { readFile } from "node:fs/promises";
import { fetchCandlesForAsset } from "./marketdata.mjs";
import { latestSignals } from "./strategy.mjs";
import { evaluateComposite } from "./signal.mjs";
import { fetchRecentHeadlines, headlinesForSymbol, scoreSentiment } from "./news.mjs";
import { loadState, saveState, shouldAlert } from "./state.mjs";
import { sendTelegramMessage } from "./telegram.mjs";
import { suggestLevels, formatLevels, decimalsForPrice, suggestPositionSize, formatPositionSize } from "./levels.mjs";

const SIGNAL_LABELS = {
  oversold: "🟢 RSI oversold (< 30) — possible long setup",
  overbought: "🔴 RSI overbought (> 70) — possible exit/short setup",
  golden_cross: "🟢 Golden cross — fast SMA crossed above slow SMA",
  death_cross: "🔴 Death cross — fast SMA crossed below slow SMA",
};

const SIGNAL_DIRECTION = {
  oversold: "bullish",
  golden_cross: "bullish",
  overbought: "bearish",
  death_cross: "bearish",
};

const CONFLUENCE_MIN_VOTES = Number(process.env.CONFLUENCE_MIN_VOTES || 3);
const CONFLUENCE_MIN_RATIO = Number(process.env.CONFLUENCE_MIN_RATIO || 0.75);
const COOLDOWN_HOURS = Number(process.env.ALERT_COOLDOWN_HOURS || 6);
// Defaults used when a watchlist asset doesn't specify its own adxMinTrend /
// longTrendPeriod. Whether these filters help turns out to depend heavily on
// both the asset AND the timeframe — see each asset's comment in
// watchlist.json and README "Honest expectations" for the actual evidence.
// These env vars are the fallback for any asset that doesn't override them.
const ADX_MIN_TREND = Number(process.env.ADX_MIN_TREND || 0);
const LONG_TREND_PERIOD = Number(process.env.LONG_TREND_PERIOD || 0);
// Optional: if both are set, alerts include a suggested position size sized
// off the stop distance (risk a fixed % of this balance per trade) — same
// convention validated in npm run backtest's "risk-sized" row. Neither is
// required; without them alerts just show the price levels as before.
const ACCOUNT_BALANCE = process.env.ACCOUNT_BALANCE ? Number(process.env.ACCOUNT_BALANCE) : null;
const RISK_PCT_PER_TRADE = Number(process.env.RISK_PCT_PER_TRADE || 1);

async function main() {
  const { TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID } = process.env;
  if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) {
    throw new Error("Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID env vars (see README).");
  }

  const watchlist = JSON.parse(await readFile(new URL("../watchlist.json", import.meta.url)));
  const state = await loadState();
  const messages = [];

  // News is optional — degrades gracefully without ANTHROPIC_API_KEY.
  const headlines = process.env.ANTHROPIC_API_KEY ? await fetchRecentHeadlines(48) : [];

  for (const asset of watchlist.assets) {
    const symbol = asset.symbol;
    const interval = asset.interval || watchlist.interval;
    // Per-asset override, falling back to the global env-var default.
    const adxMinTrend = asset.adxMinTrend != null ? asset.adxMinTrend : ADX_MIN_TREND;
    const longTrendPeriod = asset.longTrendPeriod != null ? asset.longTrendPeriod : LONG_TREND_PERIOD;
    // Daily-interval assets shouldn't re-alert every COOLDOWN_HOURS for a
    // signal that hasn't actually changed — a new daily candle only closes
    // once a day. Default to 24h for daily assets, otherwise the usual cooldown.
    const cooldownHours = asset.cooldownHours != null ? asset.cooldownHours : interval === "1d" ? 24 : COOLDOWN_HOURS;
    try {
      // Fetch enough history for the long-trend filter, with a small buffer
      // (the exact period would leave the SMA defined only on the very last
      // candle, with no margin).
      const fetchLimit = Math.max(220, longTrendPeriod + 20);
      const candles = await fetchCandlesForAsset(asset, watchlist.interval, fetchLimit);
      const { closes } = candles;
      const decimals = decimalsForPrice(closes[closes.length - 1]);

      // 2. News sentiment for this symbol, if configured (fetched before the
      // composite evaluation below, since it's a scoring input).
      const relevantHeadlines = headlinesForSymbol(headlines, symbol);
      const sentiment = relevantHeadlines.length
        ? await scoreSentiment(symbol, relevantHeadlines).catch((err) => {
            console.error(`News sentiment failed for ${symbol}:`, err.message);
            return null;
          })
        : null;

      // 3. Composite confluence across technicals + volume + news (+ this
      // asset's own ADX/long-trend filter settings). ATR is filter-independent,
      // so this one call also supplies the value crossing signals need below.
      const { price, atrValue, adxValue, longTrend, composite, isStrong } = evaluateComposite(
        candles,
        { adxMinTrend, longTrendPeriod, confluenceMinVotes: CONFLUENCE_MIN_VOTES, confluenceMinRatio: CONFLUENCE_MIN_RATIO },
        sentiment
      );

      // 1. Precise crossing-moment signals — rare, edge-triggered, always sent.
      const crossSignals = latestSignals(closes);
      for (const s of crossSignals) {
        const levels = suggestLevels(SIGNAL_DIRECTION[s.signal], price, atrValue);
        const levelsText = levels ? `\n${formatLevels(levels, decimals)}` : "";
        const sizeText = levels && ACCOUNT_BALANCE
          ? `\n${formatPositionSize(suggestPositionSize(ACCOUNT_BALANCE, RISK_PCT_PER_TRADE, price, levels.stopLoss), decimals)}`
          : "";
        messages.push(
          `${symbol} (${interval})\n${SIGNAL_LABELS[s.signal]}\nPrice: ${price}${levelsText}${sizeText}`
        );
      }

      if (isStrong && shouldAlert(state, symbol, composite.direction, cooldownHours)) {
        const emoji = composite.direction === "bullish" ? "🟢" : "🔴";
        const voteLines = composite.votes
          .map((v) => `  • ${v.name.replace(/_/g, " ")}: ${v.direction}${v.detail ? ` (${typeof v.detail === "string" ? v.detail : v.detail.reasoning ?? ""})` : ""}`)
          .join("\n");
        const levels = suggestLevels(composite.direction, price, atrValue);
        const levelsText = levels ? `\n${formatLevels(levels, decimals)}` : "";
        const sizeText = levels && ACCOUNT_BALANCE
          ? `\n${formatPositionSize(suggestPositionSize(ACCOUNT_BALANCE, RISK_PCT_PER_TRADE, price, levels.stopLoss), decimals)}`
          : "";
        const trendText = longTrend != null ? `, above SMA${longTrendPeriod}: ${price > longTrend}` : "";
        const adxText = adxValue != null ? `, ADX ${adxValue.toFixed(1)}` : "";
        messages.push(
          `${emoji} ${symbol} composite ${composite.direction} (${composite.count}/${composite.total} signals agree${adxText}${trendText})\n${voteLines}${levelsText}${sizeText}`
        );
      }
    } catch (err) {
      console.error(`Failed to evaluate ${symbol}:`, err.message);
    }
  }

  await saveState(state);

  if (messages.length === 0) {
    console.log("No signals this run.");
    return;
  }

  const text = `Trading alert bot — not financial advice. Buy/sell zones are ATR-based volatility estimates, not predictions — review before acting.\n\n${messages.join("\n\n")}`;
  await sendTelegramMessage(TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, text);
  console.log(`Sent ${messages.length} signal(s) to Telegram.`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
