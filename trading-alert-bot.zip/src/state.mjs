import { readFile, writeFile } from "node:fs/promises";

const DEFAULT_PATH = new URL("../state.json", import.meta.url);

export async function loadState(path = DEFAULT_PATH) {
  try {
    return JSON.parse(await readFile(path, "utf-8"));
  } catch {
    return {};
  }
}

export async function saveState(state, path = DEFAULT_PATH) {
  await writeFile(path, JSON.stringify(state, null, 2), "utf-8");
}

/**
 * Decides whether a symbol+direction is worth re-alerting: yes if it's a
 * new direction since last time, or if the cooldown has elapsed since the
 * last alert for this same direction. Mutates `state` in place when it
 * decides to alert (caller still has to saveState() after).
 */
export function shouldAlert(state, key, direction, cooldownHours = 6) {
  const prev = state[key];
  const now = Date.now();
  const cooldownMs = cooldownHours * 60 * 60 * 1000;

  const isNewDirection = !prev || prev.direction !== direction;
  const cooldownElapsed = !prev || now - prev.lastAlertedAt >= cooldownMs;

  if (!isNewDirection && !cooldownElapsed) return false;

  state[key] = { direction, lastAlertedAt: now };
  return true;
}
