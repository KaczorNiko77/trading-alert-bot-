// Thin wrapper around the official metaapi.cloud-sdk, grounded in its actual
// current source (v29.3.3, verified by downloading the npm package directly
// rather than guessing at API shape) — not tested against a live MetaApi
// account, since none exists in this environment. Test this yourself against
// a demo account and report back any error so it can get fixed.
//
// Imports from the "/esm-node" subpath deliberately — the bare package
// specifier resolves to a browser-targeted build that throws
// "window is not defined" under plain Node. Verified this subpath actually
// loads and instantiates correctly in this environment.
import MetaApi from "metaapi.cloud-sdk/esm-node";

// Fixed id tagging every position this bot opens, so its own trades can be
// told apart from anything else happening on the account (manual trades,
// other EAs) when reading back deal/position history.
export const BOT_MAGIC = 20260918;

/**
 * Connects to (creating if needed) a MetaApi-managed MT5 account and returns
 * a ready, synchronized RPC connection. Caller is responsible for calling
 * connection.close() when done.
 */
export async function connectAccount({ token, login, password, server }) {
  const api = new MetaApi(token);

  const accounts = await api.metatraderAccountApi.getAccountsWithInfiniteScrollPagination();
  let account = accounts.find((a) => a.login === login && a.type.startsWith("cloud"));
  if (!account) {
    account = await api.metatraderAccountApi.createAccount({
      name: "Trading alert bot",
      type: "cloud",
      login,
      password,
      server,
      platform: "mt5",
      magic: BOT_MAGIC,
    });
  }

  await account.deploy();
  await account.waitConnected();

  const connection = account.getRPCConnection();
  await connection.connect();
  await connection.waitSynchronized();

  return connection;
}

/** Account equity/balance, open positions, etc. */
export async function getAccountInfo(connection) {
  return connection.getAccountInformation();
}

/**
 * Only returns positions with magic === BOT_MAGIC by default — a manually
 * opened position on the same symbol should never get treated as the bot's
 * own and closed/modified by it. Pass includeAll: true to bypass that (used
 * nowhere currently, kept for debugging).
 */
export async function getOpenPositions(connection, { symbol, includeAll = false } = {}) {
  const positions = await connection.getPositions();
  return positions.filter((p) => (symbol ? p.symbol === symbol : true) && (includeAll || p.magic === BOT_MAGIC));
}

/**
 * Converts a desired risk amount (account currency) into a valid MT5 lot
 * size for `symbol`, given a stop distance in price units — rounds to the
 * broker's volumeStep and clamps to [minVolume, maxVolume].
 */
export async function calculateLotSize(connection, symbol, riskAmount, stopDistance) {
  const spec = await connection.getSymbolSpecification(symbol);
  if (!(stopDistance > 0) || !(spec.contractSize > 0)) return 0;

  const rawVolume = riskAmount / (stopDistance * spec.contractSize);
  const steppedVolume = Math.floor(rawVolume / spec.volumeStep) * spec.volumeStep;
  const clamped = Math.min(Math.max(steppedVolume, 0), spec.maxVolume);
  return clamped < spec.minVolume ? 0 : Number(clamped.toFixed(2));
}

export async function getPrice(connection, symbol) {
  return connection.getSymbolPrice(symbol, false);
}

/** direction: "bullish" | "bearish". Returns the MetatraderTradeResponse. */
export async function placeMarketOrder(connection, { symbol, direction, volume, stopLoss, takeProfit, comment }) {
  const options = { comment: comment?.slice(0, 26) }; // MT5 comment field is short, gets truncated by the terminal anyway
  return direction === "bullish"
    ? connection.createMarketBuyOrder(symbol, volume, stopLoss, takeProfit, options)
    : connection.createMarketSellOrder(symbol, volume, stopLoss, takeProfit, options);
}

export async function closePosition(connection, positionId) {
  return connection.closePosition(String(positionId), {});
}

/** Moves a position's stop-loss (e.g. to breakeven/entry price). Take-profit left unchanged. */
export async function modifyStopLoss(connection, positionId, stopLoss) {
  return connection.modifyPosition(String(positionId), stopLoss);
}
