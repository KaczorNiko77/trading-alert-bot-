import { XMLParser } from "fast-xml-parser";
import Anthropic from "@anthropic-ai/sdk";

const CRYPTO_FEEDS = ["https://cointelegraph.com/rss", "https://decrypt.co/feed"];
const MACRO_FEEDS = [
  "https://www.investing.com/rss/news_1.rss", // Forex News
  "https://www.investing.com/rss/news_11.rss", // Commodities & Futures News
];
const FEEDS = [...CRYPTO_FEEDS, ...MACRO_FEEDS];

const SYMBOL_KEYWORDS = {
  BTCUSDT: ["bitcoin", "btc"],
  ETHUSDT: ["ethereum", "eth", "ether"],
  SOLUSDT: ["solana", "sol"],
  "XAU/USD": ["gold", "xau", "fed", "federal reserve", "interest rate", "rate cut", "rate hike", "dollar"],
};

const parser = new XMLParser({ ignoreAttributes: false });

async function fetchFeed(url) {
  try {
    const res = await fetch(url);
    if (!res.ok) return [];
    const xml = await res.text();
    const parsed = parser.parse(xml);
    const items = parsed?.rss?.channel?.item;
    if (!items) return [];
    return (Array.isArray(items) ? items : [items]).map((item) => ({
      title: String(item.title ?? ""),
      link: String(item.link ?? ""),
      pubDate: item.pubDate ? new Date(item.pubDate) : null,
    }));
  } catch (err) {
    console.error(`Failed to fetch/parse feed ${url}:`, err.message);
    return [];
  }
}

/** Fetches recent headlines (default: last 48h) across all configured feeds. */
export async function fetchRecentHeadlines(maxAgeHours = 48) {
  const all = (await Promise.all(FEEDS.map(fetchFeed))).flat();
  const cutoff = Date.now() - maxAgeHours * 60 * 60 * 1000;
  return all.filter((item) => !item.pubDate || item.pubDate.getTime() >= cutoff);
}

// Broad macro keywords (fed, dollar, rate hike) match plenty of headlines that
// aren't actually about this symbol (e.g. crypto stories mentioning the Fed).
// Excluding titles that clearly belong to a different asset filters those out.
const EXCLUDE_KEYWORDS = {
  "XAU/USD": ["bitcoin", "crypto", "ethereum", "solana"],
};

/** Filters headlines to ones that mention the given symbol's asset by name. */
export function headlinesForSymbol(headlines, symbol) {
  const keywords = SYMBOL_KEYWORDS[symbol] || [];
  if (keywords.length === 0) return [];
  const excludes = EXCLUDE_KEYWORDS[symbol] || [];
  return headlines.filter((h) => {
    const title = h.title.toLowerCase();
    if (excludes.some((kw) => title.includes(kw))) return false;
    return keywords.some((kw) => title.includes(kw));
  });
}

const NEWS_MODEL = process.env.NEWS_MODEL || "claude-sonnet-5";

/**
 * Scores a batch of headlines for one symbol using Claude. Returns null if
 * there are no relevant headlines or no ANTHROPIC_API_KEY is configured
 * (news scoring degrades gracefully — the rest of the bot works without it).
 */
export async function scoreSentiment(symbol, headlines) {
  if (headlines.length === 0) return null;
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return null;

  const client = new Anthropic({ apiKey });
  const list = headlines.slice(0, 12).map((h, i) => `${i + 1}. ${h.title}`).join("\n");

  const message = await client.messages.create({
    model: NEWS_MODEL,
    max_tokens: 300,
    system:
      "You classify market news sentiment for a trading alert bot. Base your answer " +
      "strictly on the headlines given — don't use outside knowledge of prices or events " +
      "not mentioned. Reply with ONLY valid JSON, no markdown fences: " +
      '{"sentiment": "bullish" | "bearish" | "neutral" | "mixed", "confidence": "low" | "medium" | "high", "reasoning": "one sentence"}',
    messages: [
      {
        role: "user",
        content: `Recent headlines mentioning ${symbol}:\n${list}`,
      },
    ],
  });

  const text = message.content
    .filter((b) => b.type === "text")
    .map((b) => b.text)
    .join("")
    .trim();

  try {
    return JSON.parse(text);
  } catch {
    console.error(`Failed to parse sentiment JSON for ${symbol}:`, text);
    return null;
  }
}
