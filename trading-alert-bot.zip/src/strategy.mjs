import { rsiSeries, smaSeries } from "./indicators.mjs";

export const DEFAULT_PARAMS = {
  rsiPeriod: 14,
  fastPeriod: 20,
  slowPeriod: 50,
  oversold: 30,
  overbought: 70,
};

/**
 * Evaluates the strategy across an entire close-price series.
 * Signals:
 *  - "oversold": RSI crosses below `oversold` (potential long)
 *  - "overbought": RSI crosses above `overbought` (potential exit/short)
 *  - "golden_cross": fast SMA crosses above slow SMA (bullish trend shift)
 *  - "death_cross": fast SMA crosses below slow SMA (bearish trend shift)
 *
 * Returns an array of { index, signal } for every index a signal fires at.
 */
export function evaluateSeries(closes, params = {}) {
  const p = { ...DEFAULT_PARAMS, ...params };
  const rsiVals = rsiSeries(closes, p.rsiPeriod);
  const fast = smaSeries(closes, p.fastPeriod);
  const slow = smaSeries(closes, p.slowPeriod);

  const signals = [];
  for (let i = 1; i < closes.length; i++) {
    if (rsiVals[i] != null && rsiVals[i - 1] != null) {
      if (rsiVals[i - 1] >= p.oversold && rsiVals[i] < p.oversold) {
        signals.push({ index: i, signal: "oversold" });
      } else if (rsiVals[i - 1] <= p.overbought && rsiVals[i] > p.overbought) {
        signals.push({ index: i, signal: "overbought" });
      }
    }
    if (fast[i] != null && slow[i] != null && fast[i - 1] != null && slow[i - 1] != null) {
      if (fast[i - 1] <= slow[i - 1] && fast[i] > slow[i]) {
        signals.push({ index: i, signal: "golden_cross" });
      } else if (fast[i - 1] >= slow[i - 1] && fast[i] < slow[i]) {
        signals.push({ index: i, signal: "death_cross" });
      }
    }
  }
  return signals;
}

/** Returns signals that fired on the most recently closed candle, if any. */
export function latestSignals(closes, params = {}) {
  const all = evaluateSeries(closes, params);
  const lastIndex = closes.length - 1;
  return all.filter((s) => s.index === lastIndex);
}
