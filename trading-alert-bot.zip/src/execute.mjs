import { readFile } from "node:fs/promises";
import { fetchCandlesForAsset } from "./marketdata.mjs";
import { evaluateComposite } from "./signal.mjs";
import {
  connectAccount,
  getAccountInfo,
  getOpenPositions,
  calculateLotSize,
  getPrice,
  placeMarketOrder,
  closePosition,
  modifyStopLoss,
  BOT_MAGIC,
} from "./metatrader.mjs";
import { isKillSwitchActive, checkDailyLossLimit, capPositionSize } from "./riskGuard.mjs";
import { getNewlyClosedDeals, findBreakevenCandidates, breakevenStopLoss, markBreakevenNotified } from "./positionTracking.mjs";
import { sendTelegramMessage } from "./telegram.mjs";

const CONFLUENCE_MIN_VOTES = Number(process.env.CONFLUENCE_MIN_VOTES || 3);
const CONFLUENCE_MIN_RATIO = Number(process.env.CONFLUENCE_MIN_RATIO || 0.75);
const ADX_MIN_TREND = Number(process.env.ADX_MIN_TREND || 0);
const LONG_TREND_PERIOD = Number(process.env.LONG_TREND_PERIOD || 0);

const RISK_PCT_PER_TRADE = Number(process.env.RISK_PCT_PER_TRADE || 1);
// Independent hard ceiling regardless of what risk-based sizing calculates —
// protects against a sizing bug resulting in a much bigger position than
// intended. Not the same knob as RISK_PCT_PER_TRADE; both apply, whichever
// is more restrictive wins.
const MAX_POSITION_PCT = Number(process.env.MAX_POSITION_PCT || 10);
// Halts new entries (not existing positions — their stop/target are already
// resting orders on the broker) for the rest of the UTC day once hit.
const MAX_DAILY_LOSS_PCT = Number(process.env.MAX_DAILY_LOSS_PCT || 3);

// Real orders only go out if this is exactly "true". Anything else — unset,
// "false", a typo — runs the full pipeline and logs exactly what it would
// have done, without calling any order-placement API. This is the default
// on purpose: a new deployment, a misconfigured secret, or someone testing
// locally should never accidentally place a real order.
const EXECUTION_ENABLED = process.env.EXECUTION_ENABLED === "true";
// Whether crossing halfway to target actually MOVES the stop-loss
// (requires EXECUTION_ENABLED too) or just sends a suggestion. Off by
// default — moving your own stop is a bigger action than an alert, worth
// opting into deliberately even once you trust the entries/exits.
const AUTO_BREAKEVEN = process.env.AUTO_BREAKEVEN === "true";

async function evaluateAsset(asset, watchlist, connection, equity, notify) {
  const symbol = asset.symbol;
  const mt5Symbol = asset.mt5Symbol;
  if (!mt5Symbol) {
    console.log(`Skipping ${symbol}: no mt5Symbol set in watchlist.json (needed to trade it on MT5).`);
    return;
  }

  const adxMinTrend = asset.adxMinTrend != null ? asset.adxMinTrend : ADX_MIN_TREND;
  const longTrendPeriod = asset.longTrendPeriod != null ? asset.longTrendPeriod : LONG_TREND_PERIOD;
  const fetchLimit = Math.max(220, longTrendPeriod + 20);

  const candles = await fetchCandlesForAsset(asset, watchlist.interval, fetchLimit);
  // News sentiment isn't included here on purpose — it was never part of
  // what got backtested/validated (see README), so execution sticks to
  // exactly the technicals+volume+filters config that was actually tested.
  const { atrValue, composite, isStrong } = evaluateComposite(candles, {
    adxMinTrend,
    longTrendPeriod,
    confluenceMinVotes: CONFLUENCE_MIN_VOTES,
    confluenceMinRatio: CONFLUENCE_MIN_RATIO,
  });

  const existingPositions = await getOpenPositions(connection, { symbol: mt5Symbol });
  const existingDirection = existingPositions.length
    ? existingPositions[0].type === "POSITION_TYPE_BUY" ? "bullish" : "bearish"
    : null;

  if (!isStrong) {
    console.log(`${symbol}: no signal this run.`);
    return;
  }

  // Reversal: close the existing position, matching the backtest's exit
  // rule (stop/target/reversal, whichever comes first — stop/target are
  // already resting orders on the broker from entry time).
  if (existingDirection && existingDirection !== composite.direction) {
    for (const position of existingPositions) {
      if (EXECUTION_ENABLED) {
        await closePosition(connection, position.id);
      }
      await notify(
        `${EXECUTION_ENABLED ? "🔴 CLOSED" : "🔶 DRY RUN — would close"} ${mt5Symbol} position ${position.id} ` +
          `(reversal signal: now ${composite.direction})`
      );
    }
    return; // don't also open a new position same run — let next run confirm
  }

  // Already in a position matching this direction — nothing to do, its
  // stop/target are already resting on the broker.
  if (existingDirection === composite.direction) {
    console.log(`${symbol}: already in a ${existingDirection} position, holding.`);
    return;
  }

  if (atrValue == null) {
    console.log(`${symbol}: no ATR value available, can't size a trade.`);
    return;
  }

  const price = await getPrice(connection, mt5Symbol);
  const entryPrice = composite.direction === "bullish" ? price.ask : price.bid;
  const stopDistance = atrValue * 1.5;
  const targetDistance = atrValue * 3;
  const stopLoss = composite.direction === "bullish" ? entryPrice - stopDistance : entryPrice + stopDistance;
  const takeProfit = composite.direction === "bullish" ? entryPrice + targetDistance : entryPrice - targetDistance;

  const riskAmount = equity * (RISK_PCT_PER_TRADE / 100);
  let volume = await calculateLotSize(connection, mt5Symbol, riskAmount, stopDistance);
  volume = capPositionSize(volume, volume * entryPrice, equity, MAX_POSITION_PCT);

  if (!(volume > 0)) {
    console.log(`${symbol}: calculated position size is 0 (below broker minimum lot size), skipping.`);
    return;
  }

  const summary =
    `${mt5Symbol} ${composite.direction === "bullish" ? "BUY" : "SELL"} ${volume} lots @ ~${entryPrice.toFixed(2)}\n` +
    `Stop: ${stopLoss.toFixed(2)} | Target: ${takeProfit.toFixed(2)}\n` +
    `${composite.count}/${composite.total} signals agree, risking ${RISK_PCT_PER_TRADE}% of equity`;

  if (EXECUTION_ENABLED) {
    const result = await placeMarketOrder(connection, {
      symbol: mt5Symbol,
      direction: composite.direction,
      volume,
      stopLoss,
      takeProfit,
      comment: "confluence-bot",
    });
    await notify(`🟢 PLACED — ${summary}\nResult: ${result.stringCode}`);
  } else {
    await notify(`🔶 DRY RUN — would place:\n${summary}`);
  }
}

/** Reports any of the bot's own positions that closed (SL/TP/reversal) since the last run. */
async function reportClosedTrades(connection, notify) {
  const closed = await getNewlyClosedDeals(connection, BOT_MAGIC);
  for (const deal of closed) {
    const profitText = deal.profit >= 0 ? `+${deal.profit.toFixed(2)}` : deal.profit.toFixed(2);
    await notify(`${deal.symbol} position ${deal.positionId} closed — ${deal.reasonLabel} (${profitText})`);
  }
}

/**
 * For positions that have moved at least halfway to target, either suggests
 * moving the stop to breakeven (default) or actually moves it (AUTO_BREAKEVEN,
 * requires EXECUTION_ENABLED too) — locking in "this trade can no longer lose
 * money" once it's proven itself right, a standard risk-management practice.
 */
async function checkBreakeven(connection, notify) {
  const positions = await getOpenPositions(connection, {});
  const candidates = await findBreakevenCandidates(positions);

  for (const position of candidates) {
    const newStop = breakevenStopLoss(position);
    if (EXECUTION_ENABLED && AUTO_BREAKEVEN) {
      await modifyStopLoss(connection, position.id, newStop);
      await notify(`🔵 Moved ${position.symbol} position ${position.id} stop-loss to breakeven (${newStop.toFixed(2)}) — halfway to target reached.`);
    } else {
      await notify(
        `💡 ${position.symbol} position ${position.id} is halfway to target — consider moving stop-loss to breakeven ` +
          `(~${newStop.toFixed(2)})${AUTO_BREAKEVEN ? " (would auto-apply if EXECUTION_ENABLED were true)" : " — set AUTO_BREAKEVEN=true to do this automatically"}.`
      );
    }
    await markBreakevenNotified(position.id);
  }
}

async function main() {
  if (isKillSwitchActive()) {
    console.log("Kill switch active — skipping this run entirely.");
    return;
  }

  // Check whether there's anything to do BEFORE demanding MetaApi
  // credentials — a repo with every autoExecute left at false (the
  // shipped default) should run as a harmless no-op with zero setup.
  const watchlist = JSON.parse(await readFile(new URL("../watchlist.json", import.meta.url)));
  const assets = watchlist.assets.filter((a) => a.autoExecute);
  if (assets.length === 0) {
    console.log('No assets have "autoExecute": true in watchlist.json — nothing to do.');
    return;
  }

  const { TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, METAAPI_TOKEN, MT5_LOGIN, MT5_PASSWORD, MT5_SERVER } = process.env;
  if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) {
    throw new Error("Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID env vars.");
  }
  if (!METAAPI_TOKEN || !MT5_LOGIN || !MT5_PASSWORD || !MT5_SERVER) {
    throw new Error("Set METAAPI_TOKEN, MT5_LOGIN, MT5_PASSWORD, MT5_SERVER env vars (see README).");
  }

  const notifications = [];
  const notify = async (text) => {
    notifications.push(text);
    console.log(text);
  };

  console.log(EXECUTION_ENABLED ? "EXECUTION_ENABLED=true — real orders will be placed." : "Dry run (EXECUTION_ENABLED is not \"true\") — logging intended actions only, no orders placed.");

  const connection = await connectAccount({ token: METAAPI_TOKEN, login: MT5_LOGIN, password: MT5_PASSWORD, server: MT5_SERVER });
  try {
    const accountInfo = await getAccountInfo(connection);
    const equity = accountInfo.equity;
    console.log(`Account equity: ${equity} ${accountInfo.currency ?? ""}`);

    // Report what happened since last run before evaluating anything new.
    await reportClosedTrades(connection, notify);
    await checkBreakeven(connection, notify);

    const { halted, currentDrawdownPct } = await checkDailyLossLimit(equity, MAX_DAILY_LOSS_PCT);
    if (halted) {
      await notify(
        `⛔ Daily loss limit hit (${currentDrawdownPct.toFixed(1)}% down from today's start, limit ${MAX_DAILY_LOSS_PCT}%) — no new entries until tomorrow (UTC). Existing positions still have their own stop/target.`
      );
    } else {
      for (const asset of assets) {
        try {
          await evaluateAsset(asset, watchlist, connection, equity, notify);
        } catch (err) {
          console.error(`Failed to evaluate ${asset.symbol}:`, err.message);
        }
      }
    }
  } finally {
    await connection.close();
  }

  if (notifications.length > 0) {
    const text = `Execution bot (${EXECUTION_ENABLED ? "LIVE ORDERS" : "DRY RUN"}) — not financial advice.\n\n${notifications.join("\n\n")}`;
    await sendTelegramMessage(TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, text);
  } else {
    console.log("No actions this run.");
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
