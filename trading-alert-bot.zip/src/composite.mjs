import { rsi, sma, macdSeries, bollingerBands, smaSeries, rsiSeries } from "./indicators.mjs";
import { volumeSpike, volumeSpikeSeries } from "./volume.mjs";

/**
 * Confluence model: each indicator casts one vote (bullish/bearish/null).
 * The idea is that requiring several independent signals to agree filters
 * out more noise than trusting any single indicator — it does NOT mean
 * high accuracy, just fewer, more corroborated alerts. Direction here
 * means "trend/momentum is currently leaning this way", not "reversal
 * imminent" — that's a different (and contradictory) use of RSI/extremes,
 * so this intentionally doesn't mix the two.
 */
function technicalVotes(closes) {
  const votes = [];

  const fast = sma(closes, 20);
  const slow = sma(closes, 50);
  if (fast != null && slow != null) {
    votes.push({
      name: "sma_trend",
      direction: fast > slow ? "bullish" : "bearish",
      detail: `SMA20 ${fast.toFixed(2)} vs SMA50 ${slow.toFixed(2)}`,
    });
  }

  const r = rsi(closes, 14);
  if (r != null) {
    // Momentum reading, not an extreme/reversal reading (that's what alert.mjs's
    // separate oversold/overbought crossing check is for).
    if (r > 55) votes.push({ name: "rsi_momentum", direction: "bullish", detail: `RSI ${r.toFixed(1)}` });
    else if (r < 45) votes.push({ name: "rsi_momentum", direction: "bearish", detail: `RSI ${r.toFixed(1)}` });
  }

  const { histogram } = macdSeries(closes);
  const lastHist = histogram[histogram.length - 1];
  if (lastHist != null) {
    votes.push({
      name: "macd",
      direction: lastHist > 0 ? "bullish" : "bearish",
      detail: `histogram ${lastHist.toFixed(4)}`,
    });
  }

  const { middle } = bollingerBands(closes, 20, 2);
  const lastMiddle = middle[middle.length - 1];
  if (lastMiddle != null) {
    const price = closes[closes.length - 1];
    votes.push({
      name: "bollinger_position",
      direction: price > lastMiddle ? "bullish" : "bearish",
      detail: `price ${price} vs mid-band ${lastMiddle.toFixed(2)}`,
    });
  }

  return votes;
}

function volumeVote(closes, volumes) {
  const spike = volumeSpike(volumes);
  if (!spike || !spike.isSpike) return null;
  const priceUp = closes[closes.length - 1] > closes[closes.length - 2];
  return { name: "volume_spike", direction: priceUp ? "bullish" : "bearish", detail: spike };
}

function newsVote(newsSentiment) {
  if (!newsSentiment) return null;
  if (newsSentiment.confidence === "low") return null;
  if (newsSentiment.sentiment === "bullish") return { name: "news", direction: "bullish", detail: newsSentiment };
  if (newsSentiment.sentiment === "bearish") return { name: "news", direction: "bearish", detail: newsSentiment };
  return null; // neutral / mixed contributes no vote
}

/**
 * Combines technical, volume, and (optional) news votes into one composite
 * read. Returns the leading direction, how many votes it got, and how many
 * were cast in total, plus the individual votes for transparency in alerts.
 */
export function composeSignal(closes, volumes, newsSentiment = null) {
  const votes = [...technicalVotes(closes)];
  const vVote = volumeVote(closes, volumes);
  if (vVote) votes.push(vVote);
  const nVote = newsVote(newsSentiment);
  if (nVote) votes.push(nVote);

  const bullish = votes.filter((v) => v.direction === "bullish").length;
  const bearish = votes.filter((v) => v.direction === "bearish").length;

  let direction = "neutral";
  let count = 0;
  if (bullish > bearish) {
    direction = "bullish";
    count = bullish;
  } else if (bearish > bullish) {
    direction = "bearish";
    count = bearish;
  }

  return { direction, count, total: votes.length, votes };
}

/**
 * Same vote logic as composeSignal(), but computes every indicator's full
 * series ONCE and returns per-index results — O(n) total instead of O(n^2)
 * from re-slicing and recomputing at every index. Used by the backtester,
 * which needs this at every candle rather than just the latest one.
 * Doesn't include news (nothing to backtest against — no headline archive)
 * or per-vote detail text (not needed for a P&L simulation).
 */
export function composeSignalSeries(closes, volumes) {
  const smaFast = smaSeries(closes, 20);
  const smaSlow = smaSeries(closes, 50);
  const rsiVals = rsiSeries(closes, 14);
  const { histogram } = macdSeries(closes);
  const { middle } = bollingerBands(closes, 20, 2);
  const volSpikes = volumeSpikeSeries(volumes);

  const out = new Array(closes.length);
  for (let i = 0; i < closes.length; i++) {
    let bullish = 0;
    let bearish = 0;
    let total = 0;

    if (smaFast[i] != null && smaSlow[i] != null) {
      total++;
      if (smaFast[i] > smaSlow[i]) bullish++;
      else bearish++;
    }
    if (rsiVals[i] != null) {
      if (rsiVals[i] > 55) {
        total++;
        bullish++;
      } else if (rsiVals[i] < 45) {
        total++;
        bearish++;
      }
    }
    if (histogram[i] != null) {
      total++;
      if (histogram[i] > 0) bullish++;
      else bearish++;
    }
    if (middle[i] != null) {
      total++;
      if (closes[i] > middle[i]) bullish++;
      else bearish++;
    }
    if (volSpikes[i] && volSpikes[i].isSpike) {
      total++;
      if (i > 0 && closes[i] > closes[i - 1]) bullish++;
      else bearish++;
    }

    let direction = "neutral";
    let count = 0;
    if (bullish > bearish) {
      direction = "bullish";
      count = bullish;
    } else if (bearish > bullish) {
      direction = "bearish";
      count = bearish;
    }
    out[i] = { direction, count, total };
  }
  return out;
}
