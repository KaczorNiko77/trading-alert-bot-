// api.binance.com 451s from US-based hosts; api.binance.us is the same API shape
// and is accessible. Override via BINANCE_API_BASE if you're hosting elsewhere.
const BASE_URL = process.env.BINANCE_API_BASE || "https://api.binance.us/api/v3/klines";

// Binance's klines endpoint caps each request at 1000 candles.
const MAX_PER_REQUEST = 1000;

async function fetchKlinesBatch(symbol, interval, batchLimit, endTime) {
  let url = `${BASE_URL}?symbol=${symbol}&interval=${interval}&limit=${batchLimit}`;
  if (endTime != null) url += `&endTime=${endTime}`;
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Binance request failed for ${symbol}: ${res.status} ${res.statusText}`);
  }
  return res.json();
}

/**
 * Fetches OHLCV candles from Binance's public market-data endpoint (no API
 * key required). Transparently pages backwards in time for `limit` values
 * above 1000 (Binance's per-request cap), merging into one oldest->newest
 * array. Returns {highs, lows, closes, volumes}.
 */
export async function fetchCandles(symbol, interval = "1h", limit = 200) {
  let all = [];
  let endTime;

  while (all.length < limit) {
    const remaining = limit - all.length;
    const batchLimit = Math.min(MAX_PER_REQUEST, remaining);
    const batch = await fetchKlinesBatch(symbol, interval, batchLimit, endTime);
    if (batch.length === 0) break;

    all = [...batch, ...all]; // batch is older than everything already collected
    endTime = batch[0][0] - 1; // openTime of the earliest candle in this batch, minus 1ms
    if (batch.length < batchLimit) break; // exchange has no more history before this point
  }

  return {
    highs: all.map((k) => Number(k[2])),
    lows: all.map((k) => Number(k[3])),
    closes: all.map((k) => Number(k[4])),
    volumes: all.map((k) => Number(k[5])),
  };
}
