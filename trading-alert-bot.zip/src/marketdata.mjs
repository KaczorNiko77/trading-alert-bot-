import { fetchCandles as fetchBinanceCandles } from "./binance.mjs";
import { fetchCandles as fetchTwelveDataCandles } from "./twelvedata.mjs";

/** Fetches {highs, lows, closes, volumes} for a watchlist asset, regardless of provider. */
export async function fetchCandlesForAsset(asset, defaultInterval, limit = 200) {
  const interval = asset.interval || defaultInterval;
  if (asset.provider === "binance") return fetchBinanceCandles(asset.symbol, interval, limit);
  if (asset.provider === "twelvedata") return fetchTwelveDataCandles(asset.symbol, interval, limit);
  throw new Error(`Unknown provider "${asset.provider}" for ${asset.symbol}`);
}
