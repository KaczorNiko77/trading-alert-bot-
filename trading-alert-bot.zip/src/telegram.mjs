// Deliberately no parse_mode: Telegram's Markdown parsers throw a hard 400 on
// any unescaped/unpaired special character (_, *, [, etc.), and this message
// contains plenty of text we don't fully control — vote names with
// underscores (sma_trend, golden_cross), and free-text LLM-generated news
// reasoning. Plain text can't fail to parse, which matters more here than
// bold headers do.
export async function sendTelegramMessage(token, chatId, text) {
  const url = `https://api.telegram.org/bot${token}/sendMessage`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text }),
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Telegram send failed: ${res.status} ${body}`);
  }
}
