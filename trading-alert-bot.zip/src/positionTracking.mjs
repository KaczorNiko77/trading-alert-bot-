import { readFile, writeFile } from "node:fs/promises";

const STATE_PATH = new URL("../execution-state.json", import.meta.url);

async function loadState() {
  try {
    return JSON.parse(await readFile(STATE_PATH, "utf-8"));
  } catch {
    return {};
  }
}

async function saveState(state) {
  await writeFile(STATE_PATH, JSON.stringify(state, null, 2), "utf-8");
}

const DEAL_REASON_LABELS = {
  DEAL_REASON_SL: "🔴 stop-loss hit",
  DEAL_REASON_TP: "🟢 take-profit hit",
  DEAL_REASON_EXPERT: "closed by the bot (reversal signal)",
  DEAL_REASON_CLIENT: "closed manually",
  DEAL_REASON_MOBILE: "closed manually (mobile)",
  DEAL_REASON_WEB: "closed manually (web terminal)",
  DEAL_REASON_SO: "stopped out (margin call)",
};

/**
 * Finds deals that closed a position since the last check, filtered to this
 * bot's own trades (by magic number so a shared account's manual trades
 * aren't reported as if the bot did them). Advances and persists the
 * "last checked" timestamp so the same deal isn't reported twice.
 */
export async function getNewlyClosedDeals(connection, magic) {
  const state = await loadState();
  const since = state.lastDealCheckTime ? new Date(state.lastDealCheckTime) : new Date(Date.now() - 60 * 60 * 1000);
  const now = new Date();

  const deals = await connection.getDealsByTimeRange(since, now);
  const closed = (deals.deals ?? deals ?? [])
    .filter((d) => d.entryType === "DEAL_ENTRY_OUT" && d.magic === magic)
    .map((d) => ({
      symbol: d.symbol,
      profit: d.profit,
      positionId: d.positionId,
      reasonLabel: DEAL_REASON_LABELS[d.reason] ?? d.reason ?? "closed",
    }));

  state.lastDealCheckTime = now.toISOString();
  await saveState(state);
  return closed;
}

/**
 * For each open position that's moved at least halfway to its target,
 * suggests moving the stop-loss to breakeven (entry price) — a standard
 * risk-management move: once a trade's proven itself right, lock in "can't
 * lose money on this one anymore" instead of leaving the original stop in
 * place. Only suggests once per position (tracked in execution-state.json)
 * so it doesn't repeat every run. Returns candidates; does NOT modify
 * anything itself — see applyBreakeven() for that, called separately and
 * only when AUTO_BREAKEVEN is explicitly enabled.
 */
export async function findBreakevenCandidates(positions) {
  const state = await loadState();
  const notified = new Set(state.breakevenNotified ?? []);
  const candidates = [];

  for (const p of positions) {
    if (notified.has(String(p.id))) continue;
    if (p.stopLoss == null || p.takeProfit == null) continue;

    const isLong = p.type === "POSITION_TYPE_BUY";
    const totalDistance = isLong ? p.takeProfit - p.openPrice : p.openPrice - p.takeProfit;
    const progress = isLong ? p.currentPrice - p.openPrice : p.openPrice - p.currentPrice;
    if (totalDistance <= 0) continue;

    const alreadyAtBreakeven = isLong ? p.stopLoss >= p.openPrice : p.stopLoss <= p.openPrice;
    if (alreadyAtBreakeven) continue;

    if (progress / totalDistance >= 0.5) {
      candidates.push(p);
    }
  }
  return candidates;
}

/** Moves stop-loss to entry price (+/- a small buffer to cover the spread/commission cost). */
export function breakevenStopLoss(position) {
  const buffer = position.currentPrice * 0.0005; // ~0.05%, enough to clear typical spread/commission
  return position.type === "POSITION_TYPE_BUY" ? position.openPrice + buffer : position.openPrice - buffer;
}

export async function markBreakevenNotified(positionId) {
  const state = await loadState();
  const notified = new Set(state.breakevenNotified ?? []);
  notified.add(String(positionId));
  state.breakevenNotified = [...notified];
  await saveState(state);
}
