/**
 * Turns a direction + current price + ATR (volatility) into a concrete
 * entry zone, invalidation level, and target — sized relative to how much
 * this asset actually moves, not arbitrary numbers. Uses a 1.5x ATR stop
 * distance and a 2:1 reward:risk target (3x ATR), a common convention —
 * not a guarantee these exact multiples are optimal for any given asset.
 */
export function suggestLevels(direction, price, atrValue) {
  if (atrValue == null || direction === "neutral") return null;

  const entryBuffer = atrValue * 0.3;
  const stopDistance = atrValue * 1.5;
  const targetDistance = atrValue * 3; // 2:1 reward:risk vs. the stop distance

  if (direction === "bullish") {
    return {
      action: "buy zone",
      entryLow: price - entryBuffer,
      entryHigh: price + entryBuffer,
      stopLoss: price - stopDistance,
      target: price + targetDistance,
      riskRewardRatio: 2,
    };
  }

  return {
    action: "sell / reduce zone",
    entryLow: price - entryBuffer,
    entryHigh: price + entryBuffer,
    stopLoss: price + stopDistance, // invalidation: price recovering above this
    target: price - targetDistance, // further downside target
    riskRewardRatio: 2,
  };
}

/**
 * Sizes a position so that hitting the stop loses exactly `riskPct` of
 * `accountBalance` — the standard "risk a fixed % per trade" convention,
 * instead of betting a fixed dollar amount or a fixed % of equity
 * regardless of how far away the stop is. Backtested effect (npm run
 * backtest): drastically lower drawdown for a proportionally smaller cut
 * in total return — see README "Honest expectations".
 */
export function suggestPositionSize(accountBalance, riskPct, price, stopLoss) {
  const stopDistancePct = (Math.abs(price - stopLoss) / price) * 100;
  if (!(accountBalance > 0) || !(riskPct > 0) || stopDistancePct <= 0) return null;
  const positionFraction = Math.min(1, riskPct / stopDistancePct);
  const positionValue = accountBalance * positionFraction;
  return { positionFraction, positionValue, units: positionValue / price };
}

export function formatPositionSize(size, decimals) {
  if (!size) return "";
  return `  Suggested size: ${size.positionValue.toFixed(2)} (${(size.positionFraction * 100).toFixed(1)}% of equity, ~${size.units.toFixed(decimals)} units)`;
}

/** Reasonable decimal precision for display, scaled to the asset's price. */
export function decimalsForPrice(price) {
  if (price >= 100) return 2;
  if (price >= 1) return 3;
  return 6;
}

export function formatLevels(levels, decimals) {
  if (!levels) return "";
  const f = (n) => n.toFixed(decimals);
  const stopLabel = levels.action === "buy zone" ? "Stop-loss" : "Invalidation";
  return (
    `  ${levels.action}: ${f(levels.entryLow)} – ${f(levels.entryHigh)}\n` +
    `  ${stopLabel}: ${f(levels.stopLoss)} | Target: ${f(levels.target)} (${levels.riskRewardRatio}:1 R:R)`
  );
}
