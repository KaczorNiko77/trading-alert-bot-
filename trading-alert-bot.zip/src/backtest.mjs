import { fetchCandlesForAsset } from "./marketdata.mjs";
import { evaluateSeries } from "./strategy.mjs";
import { composeSignalSeries } from "./composite.mjs";
import { adxSeries, smaSeries, atrSeries } from "./indicators.mjs";

// Round-trip trading cost (spread + commission), as a % subtracted from each
// trade's return. Real costs vary a lot by broker/instrument (crypto retail
// ~0.1-0.2%, forex majors ~0.02-0.05%, gold CFD ~0.03-0.08% typically) — this
// default is a conservative, rough estimate, not a specific broker's number.
// Override with: node src/backtest.mjs <interval> <costPct> <candleCount> <riskPct>
const DEFAULT_COST_PCT = 0.1;
const DEFAULT_LIMIT = 3000;
// Standard "risk a fixed % of equity per trade" convention for the risk-sized
// comparison row — 1% is a common conservative default in real risk
// management, not tuned to flatter this particular backtest.
const DEFAULT_RISK_PCT = 1;

// Minimum trades before a win-rate/return number means much of anything.
const MIN_MEANINGFUL_TRADES = 20;

// Same convention as src/levels.mjs's suggestLevels(): 1.5x ATR stop,
// 3x ATR target (2:1 reward:risk). Exits check every bar's high/low, not
// just its close, so a trade that spikes through the stop intrabar is
// caught instead of riding the loss further until the next reversal signal.
const STOP_ATR_MULT = 1.5;
const TARGET_ATR_MULT = 3;

function tradeReturn(entryPrice, exitPrice, costPct, positionFraction = 1) {
  const priceReturnPct = (exitPrice / entryPrice - 1) * 100;
  return positionFraction * (priceReturnPct - costPct);
}

/**
 * Long-only trade simulator shared by both strategies below: enters on
 * `entrySignal[i]`, exits on whichever comes first — the ATR-based stop,
 * the ATR-based target, or `exitSignal[i]` (the strategy's own reversal
 * condition) as a fallback for trades that hit neither.
 *
 * `riskPct`, if given, sizes each trade so that hitting its stop loses
 * exactly `riskPct` of equity — the standard "risk a fixed % per trade"
 * convention, sized off the ATR stop distance — instead of the (unrealistic,
 * no-real-trader-does-this) default of committing 100% of equity to every
 * trade regardless of how far away its stop is.
 */
function simulateLongOnly({ closes, highs, lows, atrVals, entrySignal, exitSignal }, costPct, riskPct = null) {
  const trades = [];
  let entry = null;

  for (let i = 0; i < closes.length; i++) {
    if (entry === null) {
      if (entrySignal[i] && atrVals[i] != null) {
        const price = closes[i];
        const stop = price - atrVals[i] * STOP_ATR_MULT;
        const target = price + atrVals[i] * TARGET_ATR_MULT;
        const stopDistancePct = ((price - stop) / price) * 100;
        // Capped at 1.0: never more than 100% of equity in one trade, even
        // if the stop is unusually tight (no leverage/margin assumed).
        const positionFraction = riskPct != null ? Math.min(1, riskPct / stopDistancePct) : 1;
        entry = { price, stop, target, positionFraction };
      }
    } else {
      if (lows[i] <= entry.stop) {
        trades.push({ returnPct: tradeReturn(entry.price, entry.stop, costPct, entry.positionFraction), exitReason: "stop", positionFraction: entry.positionFraction });
        entry = null;
      } else if (highs[i] >= entry.target) {
        trades.push({ returnPct: tradeReturn(entry.price, entry.target, costPct, entry.positionFraction), exitReason: "target", positionFraction: entry.positionFraction });
        entry = null;
      } else if (exitSignal[i]) {
        trades.push({ returnPct: tradeReturn(entry.price, closes[i], costPct, entry.positionFraction), exitReason: "reversal", positionFraction: entry.positionFraction });
        entry = null;
      }
    }
  }
  return { trades, openPosition: entry !== null };
}

function summarize({ trades, openPosition }) {
  const wins = trades.filter((t) => t.returnPct > 0).length;
  const totalReturnPct = trades.reduce((acc, t) => acc * (1 + t.returnPct / 100), 1) - 1;

  let peak = 1;
  let equity = 1;
  let maxDrawdownPct = 0;
  for (const t of trades) {
    equity *= 1 + t.returnPct / 100;
    peak = Math.max(peak, equity);
    maxDrawdownPct = Math.min(maxDrawdownPct, (equity / peak - 1) * 100);
  }

  const exitCounts = { stop: 0, target: 0, reversal: 0 };
  for (const t of trades) exitCounts[t.exitReason]++;

  const avgPositionPct = trades.length
    ? (trades.reduce((a, t) => a + (t.positionFraction ?? 1), 0) / trades.length) * 100
    : null;

  return {
    trades: trades.length,
    winRatePct: trades.length ? (wins / trades.length) * 100 : null,
    strategyReturnPct: totalReturnPct * 100,
    maxDrawdownPct,
    avgPositionPct,
    exitCounts,
    openPosition,
  };
}

/**
 * Long-only backtest of the golden/death cross strategy: buy on
 * golden_cross, sell on the next death_cross (or the ATR stop/target,
 * whichever comes first).
 */
function backtestCrossStrategy({ closes, highs, lows }, costPct, riskPct = null) {
  const atrVals = atrSeries(highs, lows, closes, 14);
  const entrySignal = new Array(closes.length).fill(false);
  const exitSignal = new Array(closes.length).fill(false);
  for (const s of evaluateSeries(closes)) {
    if (s.signal === "golden_cross") entrySignal[s.index] = true;
    else if (s.signal === "death_cross") exitSignal[s.index] = true;
  }
  return summarize(simulateLongOnly({ closes, highs, lows, atrVals, entrySignal, exitSignal }, costPct, riskPct));
}

/**
 * Long-only backtest of the confluence strategy: buy when technical+volume
 * votes turn strongly bullish (matching alert.mjs's thresholds), sell on
 * the ATR stop/target or when votes turn strongly bearish, whichever comes
 * first. News isn't included — there's no historical headline archive to
 * replay, so this only tests the technicals+volume half of what the live
 * bot uses. Optionally requires ADX above `adxThreshold` as a trend-
 * strength filter, and price aligned with its `longTrendPeriod`-length SMA
 * as a long-term trend filter — set either to null/0 to disable it.
 */
function backtestConfluenceStrategy(
  { closes, volumes, highs, lows },
  costPct,
  { minVotes = 3, minRatio = 0.75, adxThreshold = 20, longTrendPeriod = 200, riskPct = null } = {}
) {
  const composite = composeSignalSeries(closes, volumes);
  const atrVals = atrSeries(highs, lows, closes, 14);
  const adxVals = adxThreshold != null ? adxSeries(highs, lows, closes, 14) : null;
  const longTrendVals = longTrendPeriod ? smaSeries(closes, longTrendPeriod) : null;

  const entrySignal = new Array(closes.length).fill(false);
  const exitSignal = new Array(closes.length).fill(false);

  for (let i = 0; i < closes.length; i++) {
    const c = composite[i];
    const ratio = c.total > 0 ? c.count / c.total : 0;
    const isTrending = adxThreshold == null || (adxVals[i] != null && adxVals[i] >= adxThreshold);
    const alignsBull = !longTrendVals || longTrendVals[i] == null || closes[i] > longTrendVals[i];
    const alignsBear = !longTrendVals || longTrendVals[i] == null || closes[i] < longTrendVals[i];

    const meetsVotes = c.count >= minVotes && ratio >= minRatio && isTrending;
    if (c.direction === "bullish" && meetsVotes && alignsBull) entrySignal[i] = true;
    else if (c.direction === "bearish" && meetsVotes && alignsBear) exitSignal[i] = true;
  }

  return summarize(simulateLongOnly({ closes, highs, lows, atrVals, entrySignal, exitSignal }, costPct, riskPct));
}

function printRow(symbol, label, result, buyHoldPct) {
  const sampleWarning = result.trades > 0 && result.trades < MIN_MEANINGFUL_TRADES
    ? `  ⚠ only ${result.trades} trades — too small a sample to draw conclusions from\n`
    : "";
  const { stop, target, reversal } = result.exitCounts;
  const sizeText = result.avgPositionPct != null && result.avgPositionPct < 99.5
    ? `  avg position size: ${result.avgPositionPct.toFixed(1)}% of equity\n`
    : "";
  console.log(`${symbol} — ${label}`);
  console.log(`  trades: ${result.trades}${result.openPosition ? " (+1 still open)" : ""} (exits: ${stop} stop, ${target} target, ${reversal} reversal)`);
  console.log(sampleWarning + `  win rate: ${result.winRatePct == null ? "n/a" : result.winRatePct.toFixed(1) + "%"}`);
  console.log(`  strategy return: ${result.strategyReturnPct.toFixed(1)}%`);
  console.log(`  buy & hold return: ${buyHoldPct.toFixed(1)}%`);
  console.log(sizeText + `  max drawdown: ${result.maxDrawdownPct.toFixed(1)}%`);
  console.log("");
}

function buyHold(closes) {
  return (closes[closes.length - 1] / closes[0] - 1) * 100;
}

async function main() {
  const watchlist = JSON.parse(
    await (await import("node:fs/promises")).readFile(new URL("../watchlist.json", import.meta.url))
  );
  const interval = process.argv[2] || "1d";
  const costPct = process.argv[3] != null ? Number(process.argv[3]) : DEFAULT_COST_PCT;
  const limit = process.argv[4] != null ? Number(process.argv[4]) : DEFAULT_LIMIT;
  const riskPct = process.argv[5] != null ? Number(process.argv[5]) : DEFAULT_RISK_PCT;

  console.log(
    `Backtesting on ${interval} candles (up to ${limit}), ${costPct}% round-trip cost assumed per\n` +
      `trade. Exits use a 1.5x/3x-ATR stop/target (same convention as live alerts), whichever\n` +
      `comes first vs. a reversal signal. News scoring is not backtested (no historical headline\n` +
      `archive) — these numbers cover technicals + volume (+ ADX/SMA200 filters where noted) only.\n`
  );

  for (const asset of watchlist.assets) {
    let candles;
    try {
      candles = await fetchCandlesForAsset({ ...asset, interval }, interval, limit);
    } catch (err) {
      console.error(`Skipping ${asset.symbol}: ${err.message}\n`);
      continue;
    }
    const { closes, volumes, highs, lows } = candles;
    if (closes.length < 300) {
      console.log(`${asset.symbol}: only ${closes.length} candles available from the data source, skipping (too short for a meaningful backtest).\n`);
      continue;
    }
    const fullBuyHold = buyHold(closes);

    printRow(asset.symbol, `golden/death cross (${closes.length} candles)`, backtestCrossStrategy(candles, costPct), fullBuyHold);
    printRow(
      asset.symbol,
      "confluence, no ADX/SMA200 filters (matches live bot default)",
      backtestConfluenceStrategy(candles, costPct, { adxThreshold: null, longTrendPeriod: null }),
      fullBuyHold
    );
    printRow(
      asset.symbol,
      `confluence, risk-sized (${riskPct}% risk per trade off the ATR stop, not 100% of equity)`,
      backtestConfluenceStrategy(candles, costPct, { adxThreshold: null, longTrendPeriod: null, riskPct }),
      fullBuyHold
    );
    printRow(
      asset.symbol,
      "confluence + ADX + SMA200 trend filters (optional, opt-in — see README)",
      backtestConfluenceStrategy(candles, costPct, { adxThreshold: 20, longTrendPeriod: 200 }),
      fullBuyHold
    );

    // Consistency check: same strategy (matching the live bot's default, no
    // filters), split into two non-overlapping halves of the window, each
    // backtested independently. If it only looks good in one half, that's a
    // regime-dependent result, not a real edge.
    const mid = Math.floor(closes.length / 2);
    const firstHalf = { closes: closes.slice(0, mid), volumes: volumes.slice(0, mid), highs: highs.slice(0, mid), lows: lows.slice(0, mid) };
    const secondHalf = { closes: closes.slice(mid), volumes: volumes.slice(mid), highs: highs.slice(mid), lows: lows.slice(mid) };
    printRow(
      asset.symbol,
      "confluence, no filters — first half of window",
      backtestConfluenceStrategy(firstHalf, costPct, { adxThreshold: null, longTrendPeriod: null }),
      buyHold(firstHalf.closes)
    );
    printRow(
      asset.symbol,
      "confluence, no filters — second half of window",
      backtestConfluenceStrategy(secondHalf, costPct, { adxThreshold: null, longTrendPeriod: null }),
      buyHold(secondHalf.closes)
    );
  }

  console.log(
    "Reminder: past performance is not predictive, and requiring more signals to agree filters\n" +
      "noise, not risk — it doesn't imply a higher win rate. If the first-half and second-half\n" +
      "numbers look very different, that's a sign of a regime-dependent result rather than a\n" +
      "durable edge. Compare strategy return to buy & hold before trusting any live alerts."
  );
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
