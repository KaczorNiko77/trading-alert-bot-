/** Simple moving average of the last `period` closes. Returns null if not enough data. */
export function sma(closes, period) {
  if (closes.length < period) return null;
  const slice = closes.slice(closes.length - period);
  return slice.reduce((a, b) => a + b, 0) / period;
}

/** Full SMA series (same length as closes, leading entries null until enough data). */
export function smaSeries(closes, period) {
  const out = new Array(closes.length).fill(null);
  let sum = 0;
  for (let i = 0; i < closes.length; i++) {
    sum += closes[i];
    if (i >= period) sum -= closes[i - period];
    if (i >= period - 1) out[i] = sum / period;
  }
  return out;
}

/**
 * Wilder's RSI (latest value). This is the standard RSI every charting
 * platform uses (TradingView's ta.rsi() included) — a recursively
 * Wilder-smoothed average that carries memory of the whole series, not a
 * flat average of just the last `period` bars. (An earlier version of this
 * function used the flat-average shortcut, which is NOT standard RSI and
 * diverges from it over time — fixed to delegate to rsiSeries() below,
 * which was already doing it correctly for the crossing-signal logic.)
 */
export function rsi(closes, period = 14) {
  const series = rsiSeries(closes, period);
  return series[series.length - 1];
}

/** Exponential moving average series. Leading entries null until enough data. */
export function emaSeries(closes, period) {
  const out = new Array(closes.length).fill(null);
  const k = 2 / (period + 1);
  let prevEma = null;
  for (let i = 0; i < closes.length; i++) {
    if (prevEma === null) {
      if (i >= period - 1) {
        const seed = closes.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0) / period;
        out[i] = seed;
        prevEma = seed;
      }
    } else {
      const val = closes[i] * k + prevEma * (1 - k);
      out[i] = val;
      prevEma = val;
    }
  }
  return out;
}

/**
 * MACD: fast EMA minus slow EMA, plus a signal line (EMA of that) and
 * histogram (macd - signal). Returns parallel arrays, null until enough data.
 */
export function macdSeries(closes, fast = 12, slow = 26, signalPeriod = 9) {
  const fastEma = emaSeries(closes, fast);
  const slowEma = emaSeries(closes, slow);
  const macdLine = closes.map((_, i) =>
    fastEma[i] != null && slowEma[i] != null ? fastEma[i] - slowEma[i] : null
  );

  // EMA of the MACD line, skipping leading nulls.
  const firstValid = macdLine.findIndex((v) => v != null);
  const signalLine = new Array(closes.length).fill(null);
  if (firstValid !== -1 && closes.length - firstValid >= signalPeriod) {
    const compact = macdLine.slice(firstValid);
    const compactSignal = emaSeries(compact, signalPeriod);
    for (let i = 0; i < compact.length; i++) {
      signalLine[firstValid + i] = compactSignal[i];
    }
  }

  const histogram = closes.map((_, i) =>
    macdLine[i] != null && signalLine[i] != null ? macdLine[i] - signalLine[i] : null
  );

  return { macdLine, signalLine, histogram };
}

/** Bollinger Bands: SMA middle band +/- stdDevMult standard deviations. */
export function bollingerBands(closes, period = 20, stdDevMult = 2) {
  const middle = smaSeries(closes, period);
  const upper = new Array(closes.length).fill(null);
  const lower = new Array(closes.length).fill(null);
  for (let i = 0; i < closes.length; i++) {
    if (middle[i] == null) continue;
    const slice = closes.slice(i - period + 1, i + 1);
    const variance = slice.reduce((a, b) => a + (b - middle[i]) ** 2, 0) / period;
    const stdDev = Math.sqrt(variance);
    upper[i] = middle[i] + stdDevMult * stdDev;
    lower[i] = middle[i] - stdDevMult * stdDev;
  }
  return { middle, upper, lower };
}

/**
 * Average True Range series (Wilder smoothing): a volatility measure — the
 * average of how much price actually moved per candle, accounting for
 * gaps. Index-aligned with `closes` (index 0 is always null since true
 * range needs a previous close); null until enough data to warm up.
 */
export function atrSeries(highs, lows, closes, period = 14) {
  const out = new Array(closes.length).fill(null);
  if (highs.length < period + 1) return out;

  const trueRanges = new Array(highs.length).fill(null);
  for (let i = 1; i < highs.length; i++) {
    trueRanges[i] = Math.max(
      highs[i] - lows[i],
      Math.abs(highs[i] - closes[i - 1]),
      Math.abs(lows[i] - closes[i - 1])
    );
  }

  let avg = trueRanges.slice(1, period + 1).reduce((a, b) => a + b, 0) / period;
  out[period] = avg;
  for (let i = period + 1; i < trueRanges.length; i++) {
    avg = (avg * (period - 1) + trueRanges[i]) / period;
    out[i] = avg;
  }
  return out;
}

/**
 * Used to size suggested entry/stop/target ranges relative to how much
 * this asset typically moves, instead of picking numbers arbitrarily.
 * Returns the latest ATR value, or null if there's not enough data.
 */
export function atr(highs, lows, closes, period = 14) {
  const series = atrSeries(highs, lows, closes, period);
  return series[series.length - 1];
}

/**
 * ADX (Average Directional Index, Wilder) series: measures trend STRENGTH,
 * not direction — high ADX means the market is actually trending, low ADX
 * means it's choppy/ranging. Used as a filter: confluence indicators like
 * RSI/MACD/SMA-cross are known to whipsaw (fire false signals back and
 * forth) in ranging markets, so alerts can require ADX above a threshold
 * as evidence there's a real trend to follow, not just noise.
 * Index-aligned with `closes`; null until enough data to warm up both
 * smoothing stages (roughly 2x `period` bars).
 */
export function adxSeries(highs, lows, closes, period = 14) {
  const out = new Array(closes.length).fill(null);
  if (highs.length < period * 2) return out;

  const trueRanges = new Array(highs.length).fill(null);
  const plusDMs = new Array(highs.length).fill(null);
  const minusDMs = new Array(highs.length).fill(null);
  for (let i = 1; i < highs.length; i++) {
    trueRanges[i] = Math.max(
      highs[i] - lows[i],
      Math.abs(highs[i] - closes[i - 1]),
      Math.abs(lows[i] - closes[i - 1])
    );
    const upMove = highs[i] - highs[i - 1];
    const downMove = lows[i - 1] - lows[i];
    plusDMs[i] = upMove > downMove && upMove > 0 ? upMove : 0;
    minusDMs[i] = downMove > upMove && downMove > 0 ? downMove : 0;
  }

  // Wilder-smoothed averages of TR, +DM, -DM — same recurrence as atrSeries().
  // The DI ratio below is scale-invariant to sum-vs-average smoothing
  // (both numerator and denominator carry the same implicit /period), so
  // this matches Wilder's original sum-based method.
  function wilderSmooth(values) {
    const smoothed = new Array(values.length).fill(null);
    let avg = values.slice(1, period + 1).reduce((a, b) => a + b, 0) / period;
    smoothed[period] = avg;
    for (let i = period + 1; i < values.length; i++) {
      avg = (avg * (period - 1) + values[i]) / period;
      smoothed[i] = avg;
    }
    return smoothed;
  }

  const smoothedTR = wilderSmooth(trueRanges);
  const smoothedPlusDM = wilderSmooth(plusDMs);
  const smoothedMinusDM = wilderSmooth(minusDMs);

  const dx = new Array(closes.length).fill(null);
  for (let i = period; i < closes.length; i++) {
    if (smoothedTR[i] == null || smoothedTR[i] === 0) continue;
    const plusDI = (100 * smoothedPlusDM[i]) / smoothedTR[i];
    const minusDI = (100 * smoothedMinusDM[i]) / smoothedTR[i];
    const sum = plusDI + minusDI;
    dx[i] = sum === 0 ? 0 : (100 * Math.abs(plusDI - minusDI)) / sum;
  }

  // Second Wilder smoothing pass: ADX is the smoothed average of DX.
  const firstDx = dx.findIndex((v) => v != null);
  if (firstDx === -1 || closes.length - firstDx < period) return out;
  let adxAvg = dx.slice(firstDx, firstDx + period).reduce((a, b) => a + b, 0) / period;
  out[firstDx + period - 1] = adxAvg;
  for (let i = firstDx + period; i < closes.length; i++) {
    adxAvg = (adxAvg * (period - 1) + dx[i]) / period;
    out[i] = adxAvg;
  }
  return out;
}

/**
 * Returns the latest ADX value, or null if there's not enough data
 * (needs roughly 2x `period` bars to warm up both smoothing stages).
 */
export function adx(highs, lows, closes, period = 14) {
  const series = adxSeries(highs, lows, closes, period);
  return series[series.length - 1];
}

/** RSI series using Wilder smoothing, for backtesting. */
export function rsiSeries(closes, period = 14) {
  const out = new Array(closes.length).fill(null);
  if (closes.length < period + 1) return out;

  let gainSum = 0;
  let lossSum = 0;
  for (let i = 1; i <= period; i++) {
    const change = closes[i] - closes[i - 1];
    if (change >= 0) gainSum += change;
    else lossSum -= change;
  }
  let avgGain = gainSum / period;
  let avgLoss = lossSum / period;
  out[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);

  for (let i = period + 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    const gain = change > 0 ? change : 0;
    const loss = change < 0 ? -change : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
    out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  }
  return out;
}
