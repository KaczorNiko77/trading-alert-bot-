// Twelve Data covers forex/commodities (like XAU/USD) that Binance doesn't have.
// Free tier: sign up at https://twelvedata.com/pricing (no card needed), ~800
// requests/day — plenty for polling a few symbols every 30 min.
const BASE_URL = "https://api.twelvedata.com/time_series";

const INTERVAL_MAP = {
  "15m": "15min",
  "30m": "30min",
  "1h": "1h",
  "4h": "4h",
  "1d": "1day",
};

export async function fetchCandles(symbol, interval = "1h", outputsize = 200) {
  const apiKey = process.env.TWELVEDATA_API_KEY;
  if (!apiKey) {
    throw new Error("Set TWELVEDATA_API_KEY to fetch non-crypto symbols like XAU/USD (see README).");
  }

  const tdInterval = INTERVAL_MAP[interval] || interval;
  const url = `${BASE_URL}?symbol=${encodeURIComponent(symbol)}&interval=${tdInterval}&outputsize=${outputsize}&apikey=${apiKey}`;
  const res = await fetch(url);
  const data = await res.json();

  if (!res.ok || data.status === "error" || !Array.isArray(data.values)) {
    throw new Error(`Twelve Data request failed for ${symbol}: ${data.message || res.statusText}`);
  }

  // Twelve Data returns newest-first; flip to oldest -> newest for consistency
  // with the rest of the bot (Binance's kline order).
  const values = [...data.values].reverse();

  return {
    highs: values.map((v) => Number(v.high)),
    lows: values.map((v) => Number(v.low)),
    closes: values.map((v) => Number(v.close)),
    // Spot FX/commodities feeds generally don't report meaningful volume —
    // Twelve Data returns 0/undefined for XAU/USD. The volume-spike vote
    // degrades gracefully (returns null, casts no vote) when this happens.
    volumes: values.map((v) => Number(v.volume) || 0),
  };
}
