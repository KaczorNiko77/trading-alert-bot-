import { readFile, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";

const STATE_PATH = new URL("../execution-state.json", import.meta.url);
const KILL_SWITCH_PATH = new URL("../KILL_SWITCH", import.meta.url);

/**
 * Hard stop, checked before anything else runs. Two ways to trip it:
 * an env var (for CI/secrets-based control) or a file in the repo root
 * (for "I'm at my desk and need to stop this right now" — just create
 * an empty file named KILL_SWITCH, no deploy needed).
 */
export function isKillSwitchActive() {
  if (String(process.env.KILL_SWITCH).toLowerCase() === "true") return true;
  return existsSync(KILL_SWITCH_PATH);
}

async function loadState() {
  try {
    return JSON.parse(await readFile(STATE_PATH, "utf-8"));
  } catch {
    return {};
  }
}

async function saveState(state) {
  await writeFile(STATE_PATH, JSON.stringify(state, null, 2), "utf-8");
}

/**
 * Tracks equity at the start of each UTC day and compares it to current
 * equity. Returns { halted, dayStartEquity, currentDrawdownPct }. Halted
 * means: don't open any NEW positions for the rest of the day — existing
 * positions still have their own stop-loss/take-profit resting on the
 * broker, so they're not abandoned, just no fresh risk is added.
 */
export async function checkDailyLossLimit(currentEquity, maxDailyLossPct) {
  const state = await loadState();
  const today = new Date().toISOString().slice(0, 10);

  if (state.dayStartDate !== today) {
    state.dayStartDate = today;
    state.dayStartEquity = currentEquity;
    await saveState(state);
  }

  const dayStartEquity = state.dayStartEquity;
  const drawdownPct = ((dayStartEquity - currentEquity) / dayStartEquity) * 100;
  const halted = maxDailyLossPct > 0 && drawdownPct >= maxDailyLossPct;

  return { halted, dayStartEquity, currentDrawdownPct: drawdownPct };
}

/**
 * Independent hard ceiling on position size, regardless of what the
 * risk/ATR-based sizing calculated — protects against a sizing bug (e.g. a
 * miscalculated stop distance) resulting in a much larger position than
 * intended. Returns the volume, capped.
 */
export function capPositionSize(volume, notionalValue, equity, maxPositionPct) {
  if (maxPositionPct <= 0) return volume;
  const maxNotional = equity * (maxPositionPct / 100);
  if (notionalValue <= maxNotional) return volume;
  return volume * (maxNotional / notionalValue);
}
