import { atr, adx, sma } from "./indicators.mjs";
import { composeSignal } from "./composite.mjs";

/**
 * Single source of truth for "is this a strong composite signal right now",
 * shared by alert.mjs (Telegram notification) and execute.mjs (actual order
 * placement) so they can never quietly diverge on what counts as a signal.
 */
export function evaluateComposite(
  { closes, highs, lows, volumes },
  { adxMinTrend, longTrendPeriod, confluenceMinVotes, confluenceMinRatio },
  sentiment = null
) {
  const price = closes[closes.length - 1];
  const atrValue = atr(highs, lows, closes, 14);
  const adxValue = adx(highs, lows, closes, 14);
  const isTrending = adxMinTrend <= 0 || (adxValue != null && adxValue >= adxMinTrend);
  const longTrend = longTrendPeriod > 0 ? sma(closes, longTrendPeriod) : null;

  const composite = composeSignal(closes, volumes, sentiment);
  const ratio = composite.total > 0 ? composite.count / composite.total : 0;
  const alignsWithLongTrend =
    longTrend == null ||
    (composite.direction === "bullish" ? price > longTrend : price < longTrend);
  const isStrong =
    composite.direction !== "neutral" &&
    composite.count >= confluenceMinVotes &&
    ratio >= confluenceMinRatio &&
    isTrending &&
    alignsWithLongTrend;

  return { price, atrValue, adxValue, longTrend, composite, isStrong };
}
