# Trading Alert Bot

Signal bot covering crypto (via Binance.US) and forex/commodities like
gold (via Twelve Data). By default it's alert-only — it pings a Telegram
chat when several independent signals agree, and you decide whether to
act on it. There's also an opt-in, off-by-default execution bridge that
can place real orders on an MT5 **demo** account — see
[`EXECUTION.md`](./EXECUTION.md). Nothing in this repo places real-money
trades unless you explicitly wire up and enable that bridge yourself.

**If you're using this to inform trades on a prop-firm / funded account,
check that firm's rules on "signal bots" first — some prop firms (Equity
Edge among them) explicitly prohibit EAs, trade copiers, *and* signal bots
in the same clause, and the penalty is typically account termination. This
bot never places trades itself, but whether even using its alerts to decide
manual trades is compliant depends on your firm's specific wording. Get
that answered by their support before relying on this for a funded account.**

**Not financial advice. Requiring multiple signals to agree filters out
noise, it does not mean high accuracy — see "Honest expectations" below.**

Prefer viewing this on a live chart with TradingView's own backtester
instead of (or alongside) Telegram alerts? See `tradingview/README.md` —
same confluence logic, ported to Pine Script.

## What it actually checks

- **Precise crossing events** (rare, always alerted): RSI crossing above
  70 / below 30, and 20/50 SMA golden/death crosses.
- **Composite confluence** (throttled, see cooldown below): a weighted
  vote across independent signals —
  - Technicals: SMA trend, RSI momentum, MACD histogram, Bollinger Band
    position.
  - Volume spike: current candle's volume vs. its recent average. This is
    the honest proxy for "big money moving" — real whale-wallet tracking
    needs a paid on-chain data service (Nansen, Arkham, Whale Alert, etc.)
    this bot doesn't have access to. A volume spike just means unusually
    high trading activity, not who's behind it.
  - News sentiment (optional, needs `ANTHROPIC_API_KEY`): pulls recent
    headlines from CoinTelegraph/Decrypt (crypto) and Investing.com's
    Forex/Commodities feeds (gold, macro — Fed decisions, dollar strength),
    filters to ones mentioning the symbol's asset, and asks Claude to
    classify sentiment strictly from those headlines (bullish/bearish/
    neutral/mixed + confidence). Skipped entirely if no key is set —
    everything else still works.
  - ADX trend-strength filter and a 200-SMA long-term trend filter are
    both available, **configured per asset in `watchlist.json`** — see
    "Honest expectations" below for why one setting doesn't fit every
    asset/timeframe. ADX (Average Directional Index) measures whether the
    market is actually trending or just choppy/ranging; the SMA filter
    only takes a signal in the direction price is on relative to its
    long-term average (published research: Brock, Lakonishok & LeBaron,
    *Journal of Finance*, 1992). Both are real, legitimate techniques
    whose value turns out to depend heavily on the specific asset and
    timeframe. Global fallback via `ADX_MIN_TREND`/`LONG_TREND_PERIOD` env
    vars for any asset that doesn't set its own.
  - An alert fires when at least `CONFLUENCE_MIN_VOTES` (default 3) votes
    agree and they're at least `CONFLUENCE_MIN_RATIO` (default 75%) of all
    votes cast that round.
- **Price levels on every alert**: a buy/sell zone, stop-loss (or
  invalidation level for sell signals), and target, sized off ATR
  (Average True Range — how much this asset typically moves per candle),
  using a 1.5x-ATR stop and 2:1 reward:risk target, **fixed at the value
  when the signal fired** (not recalculated as price moves). These are
  volatility-scaled estimates from `src/levels.mjs`, not predictions —
  they tell you "here's a reasonable range given how this asset has been
  moving," not "the price will do this." The backtest now actually
  simulates these as real exits (see below), not just alert text.
- **Optional position size suggestion**: set both `ACCOUNT_BALANCE` and
  `RISK_PCT_PER_TRADE` (default 1%) and alerts include a suggested
  position size — risking that % of the balance per trade, sized off the
  stop distance, instead of an arbitrary bet size. See "Honest
  expectations" below for how much this actually matters.

## Honest expectations

- This is not a "high win rate" system, and nothing genuinely is — if a
  strategy's backtest shows a suspiciously high win rate, that usually
  means it's overfit to the past (tuned until it matched history) or the
  rare losses are large enough to wipe out many small wins. Neither
  survives contact with new data.
- **A real bug was found and fixed**: the RSI momentum vote used to call a
  non-standard "RSI" calculation — a flat average of the last 14 bars,
  not the Wilder-smoothed recursive formula every real charting platform
  (TradingView included) actually uses. `src/indicators.mjs`'s `rsi()`
  now delegates to the correct Wilder version. This means **every backtest
  number from before this fix should be considered wrong** — not
  approximately right, wrong, since it was a different, non-standard
  indicator. Everything below is post-fix.
- `npm run backtest [interval] [costPct] [candleCount]` fetches up to
  3000 candles by default (paginated past Binance's 1000-per-request
  cap), not the original 500 — with a real sample (70-125 trades per
  variant instead of 2-20), the picture changed substantially. It reports
  the crossing strategy, confluence with no filters, confluence with the
  ADX+SMA200 filters, and a first-half/second-half consistency check —
  all against buy-and-hold, all with a round-trip trading cost applied
  (default 0.1%, second argument to override), and all exiting via a real
  1.5x/3x-ATR stop/target (whichever hits first) instead of holding until
  a reversal signal.
- **On the real sample, the ADX + SMA200 filters made every result
  measurably worse** — e.g. confluence on ETHUSDT returned +1652% over
  ~7 years unfiltered vs. +405% filtered, a huge gap, consistent in
  direction (though not magnitude) across all three crypto pairs tested.
  That's why they're off by default now (see above). This makes sense
  once you think about it: these filters are designed to sit out choppy
  conditions, and the backtest window (2018ish-2026 for these pairs) was
  dominated by strong sustained trends, not chop — so the filter mostly
  cost real winning trades without much chop to actually save you from.
  It doesn't mean the filters are useless, just that they're a trade-off
  whose value depends on the market regime, not a universal improvement —
  worth testing again in a choppier period, or on a different asset class.
- **Buy-and-hold still wins overall** on this window (BTC/ETH/SOL all had
  massive multi-year runs) — expected; beating a multi-year crypto bull
  run with an in-and-out strategy is a high bar. The unfiltered confluence
  strategy got meaningfully closer, and beat buy-and-hold outright on
  ETHUSDT. The first-half/second-half split still shows real
  regime-dependence (e.g. BTCUSDT: strategy beat buy-and-hold in the first
  half, lost badly in the second) — treat any single backtest window as
  one data point, not proof of a durable edge.
- News sentiment isn't backtested at all — there's no historical headline
  archive to replay against, so the backtest numbers only cover
  technicals + volume (+ ADX/SMA200 filters where noted).
- **Timeframe matters enormously, and so does matching filters to it.**
  Everything above was tested on daily candles — but the live bot was
  actually running everything on 1h (a leftover from before gold was
  added), a real mismatch that TradingView testing this session exposed.
  What actually got found, in order:
  1. A 1-minute gold chart lost heavily (-$822 on $10K in 5 days) — the
     indicator periods (20/50-SMA, 14-RSI, MACD 12/26/9) are tuned for
     daily-scale moves and just trade noise at 1-minute resolution.
  2. 1h and 15m crypto (Node backtest, no filters): still lost money on
     5 of 6 symbol/timeframe combinations.
  3. 1h gold, no filters (TradingView, 540 trades — a real sample):
     losing, profit factor 0.969.
  4. **1h gold, WITH the ADX+SMA200 filters** (same 540-trade window,
     154 of those trades actually taken): +19.95%, profit factor 1.152,
     27.68% max drawdown — a genuine, credible, live-verified result,
     independently confirmed twice on TradingView.
  5. 1h crypto WITH filters (Node backtest): helped across the board but
     didn't flip BTC/ETH profitable (-8.7%→-6.4%, -17.0%→-12.5%) —
     only SOL was positive either way.
  The pattern: **these filters hurt on daily (crypto's history there is
  too trend-heavy to need them) but help on 1h (choppier, more prone to
  false signals) — exactly what they're theoretically supposed to do**,
  now backed by real evidence on two different timeframes instead of one
  blanket rule. `watchlist.json` reflects this: crypto runs on daily with
  filters off (its validated best config), gold runs on 1h with filters
  on (its validated best config). Don't assume this generalizes further
  than tested — a different symbol or timeframe needs its own check in
  Strategy Tester or `npm run backtest`, not an assumption either way.
- **Position sizing changes the risk/return trade-off a lot.**
  `npm run backtest` also reports a risk-sized row (1% of equity risked
  per trade, sized off the ATR stop, capped at 100% of equity) next to
  the full-equity default. On BTCUSDT daily: full equity got +365%
  return with a **-37.6% max drawdown**; risk-sized got +41.2% return
  with only **-7.0% drawdown** (averaging 18.6% of equity per position).
  That's roughly 9x less return for about 5x less drawdown — not
  "worse," a fundamentally different, far more survivable risk profile.
  A -37.6% drawdown is the kind of thing that ends most people's real
  trading long before any long-run edge has a chance to play out.

## Setup

1. `npm install`
2. Create a Telegram bot: message [@BotFather](https://t.me/BotFather),
   run `/newbot`, copy the token it gives you.
3. Get your chat ID: message your new bot anything, then visit
   `https://api.telegram.org/bot<TOKEN>/getUpdates` and read `chat.id`
   from the response.
4. Copy `.env.example` to `.env` and fill in `TELEGRAM_BOT_TOKEN` and
   `TELEGRAM_CHAT_ID`. Optionally add `ANTHROPIC_API_KEY` for news
   sentiment (get one at https://console.anthropic.com/, billed per
   token — a few cents per day of running this).
5. For gold/forex symbols (anything with `"provider": "twelvedata"` in
   `watchlist.json`), also add `TWELVEDATA_API_KEY` — free, no card, at
   https://twelvedata.com/pricing. Not needed if you only watch crypto.
6. Edit `watchlist.json` to pick assets — each entry is
   `{ "symbol": "...", "provider": "binance" | "twelvedata" }`, plus
   optional per-asset overrides: `"interval"` (falls back to the
   top-level `interval`), `"adxMinTrend"`, `"longTrendPeriod"`, and
   `"cooldownHours"` (falls back to `ADX_MIN_TREND`/`LONG_TREND_PERIOD`/
   `ALERT_COOLDOWN_HOURS` env vars, or a sensible default — see the
   `_evidence` comments in the current file for why each asset is
   configured the way it is; don't copy a config to a new symbol without
   re-testing it). News keyword matching for a new symbol needs an entry
   added to `SYMBOL_KEYWORDS` (and optionally `EXCLUDE_KEYWORDS`) in
   `src/news.mjs`.

## Run locally

```bash
export $(cat .env | xargs)   # or use a tool like dotenv-cli
npm run backtest 1d          # evaluate strategies first (interval [costPct] [candles] [riskPct])
npm run alert                # check for live signals right now
```

## Automate it (the "semi-auto" part)

`.github/workflows/alert.yml` runs `npm run alert` on a schedule (every 30
min by default) via GitHub Actions — free for public repos, generous free
tier for private ones. It also caches `state.json` between runs so the
alert cooldown (6h by default, 24h for daily-interval assets unless a
`cooldownHours` override is set) actually holds — without it, every run
is a fresh container and you'd get paged every 30 minutes for as long as
a condition stays true.

1. Push this repo to GitHub.
2. In the repo's Settings → Secrets and variables → Actions, add
   `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` as secrets. Add
   `ANTHROPIC_API_KEY` too if you want news sentiment included, and
   `TWELVEDATA_API_KEY` if `watchlist.json` includes any `twelvedata`
   assets (e.g. gold).
3. That's it — you'll get a Telegram message when a real signal fires. No
   trades are ever placed automatically.

## If you eventually want to auto-execute trades

Don't, until backtests across multiple market regimes (not just the last
500 candles) show a real, robust edge that survives being tested on data
it wasn't tuned on. **And if the account is a prop-firm/funded account,
check their rules first, specifically** — Equity Edge, for example,
explicitly bans "Expert Advisors," "trade copiers," and "signal bots" in
the same sentence, with account closure as the stated penalty, no
exceptions listed for any account tier. Assume other prop firms have
similar clauses until you've confirmed otherwise in writing. If/when you
do auto-execute (on an account where it's actually allowed):

- Use an exchange API with a **spot, non-margin** account first.
- Hardcode a max position size and a daily loss cap that halts the bot.
- Paper-trade for at least a few weeks before real money.
- Log every decision so you can audit what the bot actually did.

## Improving the strategy further

Done so far: an ADX trend-strength filter and a 200-SMA long-term trend
filter, now **configured per asset** instead of one global on/off switch
(see above — crypto and gold need opposite settings); realistic trading
costs in the backtest; a first-half/second-half consistency check; real
ATR-based stop/target exits in the backtest (was: hold until reversal);
a paginated data fetch for a statistically real sample size (was: 500
candles / 2-20 trades, now: up to 3000 candles / 70-125 trades); a fix
for a real RSI calculation bug (see above); risk-based position sizing
(`ACCOUNT_BALANCE`/`RISK_PCT_PER_TRADE` env vars, `riskPct` Pine input,
`npm run backtest`'s risk-sized row); and fixing a real timeframe/filter
mismatch the live bot had (running crypto at 1h when daily was its
validated config) using the new per-asset settings. Still worth doing:
testing more symbols beyond BTC/ETH/SOL/gold — a narrow sample of "the
market" — checking whether other assets need yet another
timeframe/filter combination rather than assuming one of the two found
so far, and building out a hard daily-loss-limit tracker if this is
ever traded with real risk-managed capital.

On "finding strategies from top traders": that premise doesn't really
hold up — genuinely profitable strategies rarely get taught publicly
(the more people copy an edge, the faster it decays), and there's no
reliable way to verify a YouTube trader's claimed track record. The
additions above (ADX, SMA200) were chosen instead because they're
published, well-documented, and don't rely on trusting an unverified
source's claims.
